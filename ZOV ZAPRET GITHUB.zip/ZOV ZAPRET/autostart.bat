@echo off
setlocal
color 2
set "source=%ProgramFiles%\ZOVZAPRET\startmenuthatprogramfilesyea.bat"
set "autostart=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
set "dest=%autostart%\ZOVZAPRET.bat"

if exist "%dest%" (
    del /F /Q "%dest%"
    echo File removed from startup.
) else (
    if exist "%source%" (
        copy /Y "%source%" "%dest%"
        echo File added to startup.
    ) else (
        echo Source file not found.
    )
)
color 4
pause