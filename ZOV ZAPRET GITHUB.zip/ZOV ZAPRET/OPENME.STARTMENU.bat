@echo off
:: MENU
setlocal EnableDelayedExpansion
:menu
cls
set "menu_choice=null"
color 4
setlocal enabledelayedexpansion
net session >nul 2>&1
if %errorLevel% NEQ 0 (
powershell -Command "Start-Process '%~f0' -Verb runAs"
    echo Run this file as administrator.
title RUN THIS FILE AS ADMINISTRATOR OR USE INK FILE
    exit
)
echo Admin Access Granted
 echo Loading [0/1]
set "sourceFolder=%~dp0"
set "targetFolderName=ZOVZAPRET"
set "targetPath=%ProgramFiles%\%targetFolderName%"
if not exist "%targetPath%" (
    mkdir "%targetPath%"
xcopy "%sourceFolder%" "%targetPath%" /E /I /Y
    echo Folder created: %targetPath%
echo Copying finished.
) else (
    echo Loading [1/1]
)
echo thanks you for using our zapret
echo.
echo ZOV ZAPRET START MENU. Press any button to continue.
title PRESS ANY BUTTON TO CONTINUE
pause >nul
title ZOV ZAPRET START                               
echo =========  ZOV ZAPRET START  =========
echo.
echo =========  v!LOCAL_VERSION!  =========
echo 1. Working One - Working zapret.
echo 2. FAKE Testing One - Testing zapret. Don't use it.
echo 3. AutoStart - Loads this menu into autostart.
echo 4. Music Play - Plays music. No stranger.
echo 0. Exit
set /p menu_choice=Enter choice (0-4): 

if "%menu_choice%"=="1" start "" "%~dp0ws.bat"
if "%menu_choice%"=="2" start "" "%~dp0general (FAKE TLS AUTO ALT).bat"
if "%menu_choice%"=="3" start "" "%~dp0autostart.bat"
if "%menu_choice%"=="4" start "" "%~dp0source\main.mp3"
if "%menu_choice%"=="0" exit /b

start "" "https://raw.githubusercontent.com/weenkom4ik2/bembembem/refs/heads/main/zovzapretcredits"