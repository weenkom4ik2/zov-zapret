@echo off
color 4
start /b "" cmd /c "%~dp0OPENME.STARTMENU.bat"