@echo off
:: MENU
setlocal EnableDelayedExpansion
:menu
cls
set "menu_choice=null"
color 4
echo ZOV ZAPRET START MENU. Press any button to continue.
pause >nul
echo =========  ZOV ZAPRET START  =========
echo.
echo =========  v!LOCAL_VERSION!  =========
echo 1. Working One
echo 2. Testing One
echo 3. Honored One
echo 0. Exit
set /p menu_choice=Enter choice (0-3): 

if "%menu_choice%"=="1" start "" "%~dp0general (ALT9).bat"
if "%menu_choice%"=="2" start "" "%~dp0general (FAKE TLS AUTO ALT).bat"
if "%menu_choice%"=="3" start "" "%~dp0bin\-_-.vbs"
if "%menu_choice%"=="0" exit /b